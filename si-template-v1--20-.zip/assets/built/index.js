!function(){"use strict";document.querySelector(".gh-burger").addEventListener("click",(function(){document.body.classList.toggle("gh-head-open")}))}();
//# sourceMappingURL=index.js.map
